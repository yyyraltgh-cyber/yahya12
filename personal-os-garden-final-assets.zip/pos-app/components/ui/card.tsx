import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5",
        "shadow-[0_1px_2px_rgba(0,0,0,0.04),0_8px_24px_-12px_var(--color-primary)]",
        className
      )}
      {...props}
    />
  );
}
